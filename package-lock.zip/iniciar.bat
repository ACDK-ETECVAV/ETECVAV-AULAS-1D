@echo off
title Guri-Chat Server
echo Instalando dependencias (necessario apenas na primeira vez)...
call npm install
cls
echo ==========================================
echo    Iniciando o Guri-Chat...
echo ==========================================
node server.js
pause