const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// Serve os arquivos da pasta public
app.use(express.static(path.join(__dirname, 'public')));

// Quando alguém se conecta ao chat
io.on('connection', (socket) => {
    console.log('Um usuário se conectou.');

    // Quando recebe uma mensagem de alguém
    socket.on('chat message', (data) => {
        // Envia a mensagem imediatamente para todos na rede
        io.emit('chat message', data);
    });

    socket.on('disconnect', () => {
        console.log('Um usuário se desconectou.');
    });
});

const PORT = 8080;
server.listen(PORT, '0.0.0.0', () => {
    console.log('==========================================');
    console.log('🚀 Guri-Chat rodando perfeitamente!');
    console.log('💻 No seu PC, acesse: http://localhost:' + PORT);
    console.log('🌐 Na mesma rede, use seu IP: http://<SEU_IP>:' + PORT);
    console.log('==========================================');
});