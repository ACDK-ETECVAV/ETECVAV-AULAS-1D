document.addEventListener("DOMContentLoaded", () => {
  const filterButtons = document.querySelectorAll(".filter-btn");
  const products = document.querySelectorAll(".product-item");

  filterButtons.forEach(button => {
    button.addEventListener("click", () => {
      filterButtons.forEach(btn => btn.classList.remove("active"));
      button.classList.add("active");

      const filter = button.dataset.filter;
      products.forEach(product => {
        product.classList.toggle(
          "d-none",
          filter !== "todos" && product.dataset.category !== filter
        );
      });
    });
  });

  document.querySelectorAll(".buy-btn").forEach(button => {
    button.addEventListener("click", () => {
      const product = button.dataset.product;
      alert(`Interesse registrado no produto: ${product}\n\nConecte este botão a um WhatsApp, e-mail ou backend para receber pedidos reais.`);
    });
  });

  const form = document.getElementById("budgetForm");
  const message = document.getElementById("formMessage");

  if (form && message) {
    form.addEventListener("submit", event => {
      event.preventDefault();
      const name = new FormData(form).get("nome");
      message.textContent = `Obrigado, ${name}! Sua solicitação foi registrada apenas como demonstração neste site.`;
      message.classList.remove("d-none");
      form.reset();
    });
  }
});
