# ACKP | INF. — Site institucional e loja

## Estrutura

- `index.html` — página inicial/resumo da empresa
- `sobre.html` — história, proposta, equipe e redes sociais
- `servicos.html` — serviços oferecidos
- `loja.html` — produtos/configurações em destaque e formulário
- `style.css` — identidade visual e estilos personalizados
- `script.js` — filtros da loja, botões e formulário
- `assets/` — logo e artes enviadas

## Tecnologias

- HTML5
- CSS3
- JavaScript
- Bootstrap 5.3 via CDN

## Como executar

Abra o `index.html` em um navegador. Como o Bootstrap é carregado por CDN, é necessária conexão com a internet para carregar a biblioteca.

Para colocar a loja em produção, o formulário e os botões de interesse podem ser conectados a um backend, banco de dados, WhatsApp ou serviço de e-mail.
