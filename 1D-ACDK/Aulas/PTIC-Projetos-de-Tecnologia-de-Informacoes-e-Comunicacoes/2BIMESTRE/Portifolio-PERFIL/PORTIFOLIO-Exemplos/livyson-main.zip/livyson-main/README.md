<!-- Profile README.md -->

<div align="center">

<img src="https://capsule-render.vercel.app/api?type=waving&color=F97316&height=200&section=header&text=Hello,%20I'm%20Livyson!%20🚀&fontSize=42&fontColor=ffffff&animation=fadeIn&fontAlignY=38" width="100%" alt="header" />

<a href="https://github.com/livyson">
  <img src="https://readme-typing-svg.demolab.com?font=Fira+Code&weight=600&size=22&pause=1000&color=F97316&center=true&vCenter=true&width=650&lines=Head+of+Engineering+%26+Product;Cloud-Native+%7C+Microservices+%7C+EDA;Data+%26+AI-Driven+Product+Leader;15%2B+years+building+high-performing+teams" alt="typing" />
</a>

<br/>

<img src="https://komarev.com/ghpvc/?username=livyson&label=Profile%20views&color=f97316&style=flat" alt="profile views" />

</div>

---

### 👨🏾‍💻 About me

- 🚀 **Head of Engineering & Product** at [Vittude](https://vittude.com/), leading the strategy for product and engineering areas.
- 🛡️ **Head of Technology** at [idwall](https://www.idwall.co), leading an area, aligning tech strategy, and boosting operational efficiency by over **77.41%**.
- 💸 **Engineering Tech Manager** at [PicPay](https://www.picpay.com), migrated to event-driven architecture and scaled the platform by **210%** with robust CI/CD pipelines on AWS.
- 🎓 **University IT Professor** at [UNINASSAU](https://www.uninassau.edu.br), teaching Project Management, Software Engineering, and Systems Analysis.
- 🧩 **Tech Lead & Software Engineer** at [CESAR](https://www.cesar.org.br/), and **Back-end Developer** at [Ogilvy](https://www.ogilvy.com/), building automation frameworks and scalable APIs in Java and Python.
- ⚡ Passionate about **cloud-native architectures**, **microservices**, **EDA**, **data analytics** and mentoring high-performing teams.

<br/>

### 🎮 Contribution Pac-Man

<div align="center">

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/livyson/livyson/c4d9e31c0650cc738ce0a4d55ace79f5d50dbb0c/pacman-contribution-graph-dark.svg">
  <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/livyson/livyson/c4d9e31c0650cc738ce0a4d55ace79f5d50dbb0c/pacman-contribution-graph.svg">
  <img alt="pacman contribution graph" src="https://raw.githubusercontent.com/livyson/livyson/c4d9e31c0650cc738ce0a4d55ace79f5d50dbb0c/pacman-contribution-graph.svg">
</picture>

</div>

<br/>

### 📊 GitHub Stats

<div align="center">

<img src="https://raw.githubusercontent.com/livyson/livyson/c4d9e31c0650cc738ce0a4d55ace79f5d50dbb0c/contribution-graph.svg" width="100%" alt="biweekly contribution graph" />

<br/>

<img src="https://raw.githubusercontent.com/livyson/livyson/c4d9e31c0650cc738ce0a4d55ace79f5d50dbb0c/activity-overview.svg" width="580" alt="activity overview" />

</div>

<br/>

### 🍕 Tech Distribution

<div align="center">

<img src="https://raw.githubusercontent.com/livyson/livyson/c4d9e31c0650cc738ce0a4d55ace79f5d50dbb0c/tech-distribution.svg" width="900" alt="technology distribution pie chart" />

</div>

<br/>

### 🛠️ Tech Stack

<table align="center" width="100%">
<thead>
<tr>
<td align="center" valign="top" width="50%">

**Languages & Runtimes**

![Java](https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=openjdk&logoColor=white)
![Python](https://img.shields.io/badge/Python-3572A5?style=for-the-badge&logo=python&logoColor=white)
![TypeScript](https://img.shields.io/badge/TypeScript-3178C6?style=for-the-badge&logo=typescript&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![Ruby](https://img.shields.io/badge/Ruby-CC342D?style=for-the-badge&logo=ruby&logoColor=white)

</td>
<td align="center" valign="top" width="50%">

**Backend & APIs**

![Spring Boot](https://img.shields.io/badge/Spring%20Boot-6DB33F?style=for-the-badge&logo=springboot&logoColor=white)
![Spring Security](https://img.shields.io/badge/Spring%20Security-6DB33F?style=for-the-badge&logo=springsecurity&logoColor=white)
![Hibernate](https://img.shields.io/badge/Hibernate-59666C?style=for-the-badge&logo=hibernate&logoColor=white)
![GraphQL](https://img.shields.io/badge/GraphQL-E10098?style=for-the-badge&logo=graphql&logoColor=white)

</td>
</tr>
</thead>
<tbody>
<tr>
<td align="center" valign="top" width="50%">

**Data & Messaging**

![PostgreSQL](https://img.shields.io/badge/PostgreSQL-4169E1?style=for-the-badge&logo=postgresql&logoColor=white)
![MongoDB](https://img.shields.io/badge/MongoDB-47A248?style=for-the-badge&logo=mongodb&logoColor=white)
![Redis](https://img.shields.io/badge/Redis-DC382D?style=for-the-badge&logo=redis&logoColor=white)
![RabbitMQ](https://img.shields.io/badge/RabbitMQ-FF6600?style=for-the-badge&logo=rabbitmq&logoColor=white)
![dbt](https://img.shields.io/badge/dbt-FF694B?style=for-the-badge&logo=dbt&logoColor=white)
![Airflow](https://img.shields.io/badge/Airflow-017CEE?style=for-the-badge&logo=apacheairflow&logoColor=white)

</td>
<td align="center" valign="top" width="50%">
<strong>Cloud & DevOps</strong><br>
<img src="https://img.shields.io/badge/Google%20Cloud%20Platform-4285F4?style=for-the-badge&logo=googlecloud&logoColor=white" alt="Google Cloud Platform" /><br>
<strong>AI</strong><br>
<img src="https://img.shields.io/badge/Claude%20API-D97757?style=for-the-badge&logo=claude&logoColor=white" alt="Claude API" />
<img src="https://img.shields.io/badge/GPT%20API-412991?style=for-the-badge&logo=openai&logoColor=white" alt="GPT API" />
</td>
</tr>
</tbody>
</table>

<br/>

### 🌐 Find me at

<div align="center">

<a href="https://www.linkedin.com/in/livyson/" title="LinkedIn (Cmd/Ctrl+click abre em nova aba)"><img src="https://img.shields.io/badge/LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn" /></a>
<a href="https://mail.google.com/mail/?view=cm&fs=1&tf=1&to=livyson@gmail.com" title="Gmail (Cmd/Ctrl+click abre em nova aba)"><img src="https://img.shields.io/badge/Email-D14836?style=for-the-badge&logo=gmail&logoColor=white" alt="Email" /></a>

</div>

<img src="https://capsule-render.vercel.app/api?type=waving&color=F97316&height=120&section=footer" width="100%" alt="footer" />
