#!/usr/bin/env node
/**
 * Gera um radar chart (Activity Overview) com:
 * Commits, Pull requests, Issues e Code review.
 */

import fs from "node:fs";
import path from "node:path";

const username = process.env.GITHUB_ACTOR || "livyson";
const token = process.env.GITHUB_TOKEN;

if (!token) {
  console.error("Missing GITHUB_TOKEN");
  process.exit(1);
}

// Janela padrão do GitHub (= último ano), igual ao Activity Overview do perfil.
const query = `
  query($login: String!) {
    user(login: $login) {
      contributionsCollection {
        totalCommitContributions
        totalIssueContributions
        totalPullRequestContributions
        totalPullRequestReviewContributions
        restrictedContributionsCount
      }
    }
  }
`;

/**
 * Percentuais públicos do Activity Overview do perfil.
 * O GraphQL (GITHUB_TOKEN / PAT limitado) omite a maior parte das contribuições
 * privadas/org como restrictedContributionsCount e zera o radar.
 */
async function fetchProfilePercents() {
  const res = await fetch(`https://github.com/users/${username}/contributions`, {
    headers: {
      Accept: "text/html",
      "User-Agent": "livyson-activity-overview",
    },
  });
  if (!res.ok) {
    throw new Error(`Profile contributions page failed: HTTP ${res.status}`);
  }

  const html = await res.text();
  const match = html.match(/data-percentages="([^"]+)"/);
  if (!match) {
    throw new Error("data-percentages not found on contributions page");
  }

  const raw = JSON.parse(match[1].replaceAll("&quot;", '"'));
  const percents = {
    commits: Number(raw.Commits) || 0,
    pullRequests: Number(raw["Pull requests"]) || 0,
    issues: Number(raw.Issues) || 0,
    codeReview: Number(raw["Code review"]) || 0,
  };
  const sum =
    percents.commits +
    percents.pullRequests +
    percents.issues +
    percents.codeReview;
  if (sum !== 100) {
    throw new Error(`Profile percents sum to ${sum}, expected 100: ${JSON.stringify(percents)}`);
  }
  return percents;
}

async function fetchContributionPool() {
  const res = await fetch("https://api.github.com/graphql", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      "User-Agent": "livyson-activity-overview",
    },
    body: JSON.stringify({
      query,
      variables: { login: username },
    }),
  });

  const payload = await res.json();
  if (!res.ok || payload.errors) {
    throw new Error(
      `GitHub GraphQL failed: ${JSON.stringify(payload.errors || payload)}`,
    );
  }

  const c = payload.data.user.contributionsCollection;
  const visible =
    (c.totalCommitContributions || 0) +
    (c.totalIssueContributions || 0) +
    (c.totalPullRequestContributions || 0) +
    (c.totalPullRequestReviewContributions || 0);
  const restricted = c.restrictedContributionsCount || 0;
  return {
    visible,
    restricted,
    total: visible + restricted,
    typed: {
      commits: c.totalCommitContributions || 0,
      pullRequests: c.totalPullRequestContributions || 0,
      issues: c.totalIssueContributions || 0,
      codeReview: c.totalPullRequestReviewContributions || 0,
    },
  };
}

function allocateByPercents(percents, total) {
  const entries = [
    ["commits", percents.commits],
    ["pullRequests", percents.pullRequests],
    ["issues", percents.issues],
    ["codeReview", percents.codeReview],
  ];
  if (total <= 0) {
    return {
      commits: 0,
      pullRequests: 0,
      issues: 0,
      codeReview: 0,
    };
  }

  const raw = entries.map(([key, pct]) => {
    const exact = (pct / 100) * total;
    return { key, exact, base: Math.floor(exact), frac: exact - Math.floor(exact) };
  });
  let remaining = total - raw.reduce((sum, item) => sum + item.base, 0);
  raw
    .slice()
    .sort((a, b) => b.frac - a.frac)
    .forEach((item) => {
      if (remaining > 0) {
        item.base += 1;
        remaining -= 1;
      }
    });

  return {
    commits: raw.find((item) => item.key === "commits").base,
    pullRequests: raw.find((item) => item.key === "pullRequests").base,
    issues: raw.find((item) => item.key === "issues").base,
    codeReview: raw.find((item) => item.key === "codeReview").base,
  };
}

async function fetchContributions() {
  const year = new Date().getUTCFullYear();
  const pool = await fetchContributionPool();

  try {
    const percents = await fetchProfilePercents();
    const counts = allocateByPercents(percents, pool.total);
    console.log("Source: profile Activity Overview percentages");
    console.log("Pool:", pool);
    return {
      year,
      ...counts,
      percents: { ...percents, total: pool.total },
    };
  } catch (error) {
    console.warn("Profile scrape failed, falling back to GraphQL typed totals:", error.message);
    return {
      year,
      ...pool.typed,
      percents: null,
    };
  }
}

function toPercents(counts) {
  if (counts.percents) {
    return counts.percents;
  }

  const entries = [
    ["commits", counts.commits],
    ["pullRequests", counts.pullRequests],
    ["issues", counts.issues],
    ["codeReview", counts.codeReview],
  ];
  const total = entries.reduce((sum, [, value]) => sum + value, 0);
  if (total === 0) {
    return {
      commits: 0,
      pullRequests: 0,
      issues: 0,
      codeReview: 0,
      total: 0,
    };
  }

  // Largest remainder method — soma sempre 100
  const raw = entries.map(([key, value]) => {
    const exact = (value / total) * 100;
    return { key, exact, base: Math.floor(exact), frac: exact - Math.floor(exact) };
  });
  let remaining = 100 - raw.reduce((sum, item) => sum + item.base, 0);
  raw
    .slice()
    .sort((a, b) => b.frac - a.frac)
    .forEach((item) => {
      if (remaining > 0) {
        item.base += 1;
        remaining -= 1;
      }
    });

  return {
    commits: raw.find((item) => item.key === "commits").base,
    pullRequests: raw.find((item) => item.key === "pullRequests").base,
    issues: raw.find((item) => item.key === "issues").base,
    codeReview: raw.find((item) => item.key === "codeReview").base,
    total,
  };
}

function point(cx, cy, radius, angleDeg) {
  const rad = ((angleDeg - 90) * Math.PI) / 180;
  return {
    x: cx + radius * Math.cos(rad),
    y: cy + radius * Math.sin(rad),
  };
}

function buildSvg(counts, percents) {
  // Extra altura/largura para acomodar 2 linhas de label sem clip
  const width = 580;
  const height = 430;
  const cx = width / 2;
  const cy = height / 2 + 4;
  const maxR = 105;

  // topo=Code review, direita=Issues, baixo=PRs, esquerda=Commits
  const axes = [
    { key: "codeReview", label: "Code review", angle: 0, count: counts.codeReview },
    { key: "issues", label: "Issues", angle: 90, count: counts.issues },
    { key: "pullRequests", label: "Pull requests", angle: 180, count: counts.pullRequests },
    { key: "commits", label: "Commits", angle: 270, count: counts.commits },
  ];

  const dataPoints = axes.map((axis) => {
    const value = percents[axis.key];
    const r = (value / 100) * maxR;
    return { ...axis, value, ...point(cx, cy, r, axis.angle) };
  });

  const polygon = dataPoints
    .map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`)
    .join(" ");

  const axisLines = axes
    .map((axis) => {
      const end = point(cx, cy, maxR, axis.angle);
      return `<line x1="${cx}" y1="${cy}" x2="${end.x.toFixed(1)}" y2="${end.y.toFixed(1)}" stroke="#ea580c" stroke-width="1.5" />`;
    })
    .join("\n");

  const rings = [0.25, 0.5, 0.75, 1]
    .map((scale) => {
      const pts = axes
        .map((axis) => {
          const p = point(cx, cy, maxR * scale, axis.angle);
          return `${p.x.toFixed(1)},${p.y.toFixed(1)}`;
        })
        .join(" ");
      return `<polygon class="ring" points="${pts}" fill="none" stroke-width="1" />`;
    })
    .join("\n");

  const font =
    "-apple-system,BlinkMacSystemFont,Segoe UI,Helvetica,Arial,sans-serif";

  const labels = axes
    .map((axis) => {
      const value = percents[axis.key];
      // Empurra labels laterais mais para fora — textos longos como "Pull requests"
      const labelRadius =
        axis.angle === 90 || axis.angle === 270 ? maxR + 86 : maxR + 58;
      const labelPos = point(cx, cy, labelRadius, axis.angle);
      const anchor =
        axis.angle === 90 ? "start" : axis.angle === 270 ? "end" : "middle";

      // Duas tags <text> com Y absoluto — NÃO usar <tspan dy>, que o Camo/SVG
      // do GitHub frequentemente ignora e faz as linhas se sobreporem.
      let titleY = labelPos.y;
      if (axis.angle === 0) titleY -= 10;
      if (axis.angle === 180) titleY += 8;
      const subY = titleY + 18;

      const title = `${value}% ${axis.label}`;
      const subtitle = `${axis.count.toLocaleString("en-US")} contributions`;

      return [
        `<text class="fg" x="${labelPos.x.toFixed(1)}" y="${titleY.toFixed(1)}" text-anchor="${anchor}" font-size="14" font-weight="600" font-family="${font}">${title}</text>`,
        `<text class="muted" x="${labelPos.x.toFixed(1)}" y="${subY.toFixed(1)}" text-anchor="${anchor}" font-size="12" font-weight="400" font-family="${font}">${subtitle}</text>`,
      ].join("\n");
    })
    .join("\n");

  const dots = dataPoints
    .map(
      (p) =>
        `<circle class="dot" cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="5" stroke="#ea580c" stroke-width="2" />`,
    )
    .join("\n");

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="GitHub activity overview for ${counts.year}">
  <style>
    .muted { fill: #57606a; }
    .fg { fill: #24292f; }
    .ring { stroke: #fdba74; }
    .dot { fill: #ffffff; }
    .radar { fill: rgba(249, 115, 22, 0.22); }
    @media (prefers-color-scheme: dark) {
      .muted { fill: #8b949e; }
      .fg { fill: #e6edf3; }
      .ring { stroke: #9a3412; }
      .dot { fill: #0d1117; }
      .radar { fill: rgba(249, 115, 22, 0.28); }
    }
  </style>
  <text class="muted" x="${cx}" y="26" text-anchor="middle" font-size="13" font-family="-apple-system,BlinkMacSystemFont,Segoe UI,Helvetica,Arial,sans-serif">Activity overview · ${counts.year} · ${percents.total.toLocaleString("en-US")} total</text>
  ${rings}
  ${axisLines}
  <polygon class="radar" points="${polygon}" stroke="#ea580c" stroke-width="2" stroke-linejoin="round" />
  ${dots}
  ${labels}
</svg>
`;
}

async function main() {
  const counts = await fetchContributions();
  const percents = toPercents(counts);
  console.log("Counts:", counts);
  console.log("Percents:", percents);

  const svg = buildSvg(counts, percents);
  const distDir = path.join(process.cwd(), "dist");
  fs.mkdirSync(distDir, { recursive: true });
  const outPath = path.join(distDir, "activity-overview.svg");
  fs.writeFileSync(outPath, svg, "utf8");
  console.log(`Wrote ${outPath}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
